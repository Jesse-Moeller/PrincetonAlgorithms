import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private WeightedQuickUnionUF biConnectedGrid;
    private WeightedQuickUnionUF uniConnectedGrid;
    private int size;
    private boolean[] sites;
    private int numberOpenSites;

    // creates n-by-n biConnectedGrid, with all sites initially blocked
    public Percolation(int n) {
        if (n > 0) {
            this.biConnectedGrid = new WeightedQuickUnionUF(n * n + 2);
            this.uniConnectedGrid = new WeightedQuickUnionUF(n * n + 2);
            this.size = n;
            this.sites = new boolean[n * n + 2];
            this.numberOpenSites = 0;
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    private int getIdx(int row, int col) {
        return (row - 1) * this.size + col;
    }

    private boolean isValidRowCol(int row, int col) {
        return (row >= 1) && (col >= 1) && (row <= this.size) && (col <= this.size);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        if (isValidRowCol(row, col)) {
            if (!isOpen(row, col)) {
                int currentidx = getIdx(row, col);
                this.sites[currentidx] = true;
                this.numberOpenSites++;
                if (row == 1) {
                    this.biConnectedGrid.union(currentidx, 0);
                    this.uniConnectedGrid.union(currentidx, 0);
                }
                if (row == this.size) {
                    this.biConnectedGrid.union(currentidx, this.size * this.size + 1);
                }
                if (isValidRowCol(row - 1, col) && isOpen(row - 1, col)) {
                        int leftidx = getIdx(row-1, col);
                       this.biConnectedGrid.union(currentidx, leftidx);
                       this.uniConnectedGrid.union(currentidx, leftidx);
                }
                
                if (isValidRowCol(row + 1, col) && isOpen(row + 1, col)) {
                        int rightidx = getIdx(row+1, col);
                       this.biConnectedGrid.union(currentidx, rightidx);
                       this.uniConnectedGrid.union(currentidx, rightidx);
                }
                
                if (isValidRowCol(row, col - 1) && isOpen(row, col - 1)) {
                        int upidx = getIdx(row, col-1);
                       this.biConnectedGrid.union(currentidx, upidx);
                       this.uniConnectedGrid.union(currentidx, upidx);
                }

                if (isValidRowCol(row, col + 1) && isOpen(row, col + 1)) {
                        int downidx = getIdx(row, col+1);
                       this.biConnectedGrid.union(currentidx, downidx);
                       this.uniConnectedGrid.union(currentidx, downidx);
                }
            }
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (isValidRowCol(row, col)) {
            return this.sites[getIdx(row, col)];
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (isValidRowCol(row, col)) {
            return (isOpen(row, col) && (uniConnectedGrid.find(getIdx(row, col)) == this.uniConnectedGrid.find(0)));
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return this.numberOpenSites;
    }

    // does the system percolate?
    public boolean percolates() {
        return (biConnectedGrid.find(0) == biConnectedGrid.find(this.size * this.size + 1));
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation myPercolation = new Percolation(3);
        myPercolation.open(1, 3);
        StdOut.println(myPercolation.isFull(1, 3));
        myPercolation.open(2, 3);
        StdOut.println(myPercolation.isFull(2, 3));
        myPercolation.open(3, 3);
        StdOut.println(myPercolation.isFull(3, 3));
        myPercolation.open(3, 1);
        StdOut.println(myPercolation.isFull(3, 1));
        myPercolation.open(2, 1);
        StdOut.println(myPercolation.isFull(2, 2));
        myPercolation.open(1, 1);
        StdOut.println(myPercolation.isFull(1, 1));
    }
}
